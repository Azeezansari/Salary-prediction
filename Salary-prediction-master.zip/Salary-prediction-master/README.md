# Salary-prediction

Salary prediction using simple linear regression. Got the dataset from Kaggle.
